# Dawid Krężelewski - Portfolio

Ultra nowoczesna strona portfolio programisty z pasji.

## 🚀 Funkcje
- Responsywny design
- Nowoczesne animacje
- Glassmorphism effects
- Smooth scrolling
- Contact form

## 🛠️ Technologie
- HTML5
- CSS3 (Custom Properties, Flexbox, Grid)
- Vanilla JavaScript
- Font Awesome Icons
- Google Fonts

## 📱 Deployment
Strona jest hostowana na Vercel.com dla najlepszej wydajności.

---
© 2024 Dawid Krężelewski. Wszystkie prawa zastrzeżone.